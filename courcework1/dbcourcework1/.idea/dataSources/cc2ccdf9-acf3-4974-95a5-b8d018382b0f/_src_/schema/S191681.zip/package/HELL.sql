create package hell as
procedure hell(id int);

end;
end;
end;
end
end;