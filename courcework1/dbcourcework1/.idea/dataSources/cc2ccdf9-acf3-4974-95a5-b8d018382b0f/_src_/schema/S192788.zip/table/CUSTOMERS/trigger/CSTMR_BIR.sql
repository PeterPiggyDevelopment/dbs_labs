create trigger CSTMR_BIR
	before insert
	on CUSTOMERS
	for each row
BEGIN
    SELECT cstmr_seq_key.NEXTVAL
    INTO   :new.id
    FROM   dual;
  END;