create trigger SUPPL_BIR
	before insert
	on SUPPLIERS
	for each row
BEGIN
    SELECT suppl_seq_key.NEXTVAL
    INTO   :new.id
    FROM   dual;
  END;