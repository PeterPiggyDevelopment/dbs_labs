create trigger CPU_BIR
	before insert
	on CPUS
	for each row
BEGIN
  SELECT cpu_seq_key.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;