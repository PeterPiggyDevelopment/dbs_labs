create trigger PROD_BIR
	before insert
	on PRODUCTION
	for each row
BEGIN
    SELECT prod_seq_key.NEXTVAL
    INTO   :new.id
    FROM   dual;
  END;