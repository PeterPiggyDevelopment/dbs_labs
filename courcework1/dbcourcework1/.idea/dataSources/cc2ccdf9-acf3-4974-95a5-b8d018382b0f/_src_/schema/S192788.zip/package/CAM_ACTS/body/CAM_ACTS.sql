create PACKAGE body cam_acts AS
    PROCEDURE insert_cam (up_id int, rear int, front int) IS
    cam CAMERA;
    BEGIN
        cam := camera(rear, front);
        update PHONES set CAMERA = cam where id = up_id;
    END;
end cam_acts;