create PROCEDURE open_acct (new_acct IN OUT employee_typ) IS
DECLARE
    cam CAMERA;
    BEGIN
        cam := camera(12, 14);
        insert into PHONES (CAMERA) values ( cam );
    END;