create PROCEDURE insert_cam (up_id int) IS
cam CAMERA;
BEGIN
    cam := camera(12, 14);
    update PHONES set CAMERA = cam where id = up_id;
END;