create trigger PHONE_BIR
	before insert
	on PHONES
	for each row
BEGIN
    SELECT phone_seq_key.NEXTVAL
    INTO   :new.id
    FROM   dual;
  END;