create TYPE customer_row_type IS OBJECT
(
  id int,
  firstname varchar(255),
  lastname varchar(255),
  middlename varchar(255),
  register_address varchar(255),
  citizenship_country_id int
)