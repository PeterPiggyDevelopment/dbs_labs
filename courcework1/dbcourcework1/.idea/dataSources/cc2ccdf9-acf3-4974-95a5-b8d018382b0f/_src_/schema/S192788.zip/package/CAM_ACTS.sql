create PACKAGE cam_acts AS
    PROCEDURE insert_cam (up_id int, rear int, front int);
end cam_acts;