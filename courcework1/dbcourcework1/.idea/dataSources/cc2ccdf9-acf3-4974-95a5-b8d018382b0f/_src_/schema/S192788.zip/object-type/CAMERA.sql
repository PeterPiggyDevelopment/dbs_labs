create type camera as OBJECT
(
  REAR_CAMERA_MP INT,
  FRONT_CAMERA_MP INT
)