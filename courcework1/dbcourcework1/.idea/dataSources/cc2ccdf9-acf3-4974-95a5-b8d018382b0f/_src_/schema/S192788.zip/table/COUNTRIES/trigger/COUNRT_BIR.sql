create trigger COUNRT_BIR
	before insert
	on COUNTRIES
	for each row
BEGIN
    SELECT countr_seq_key.NEXTVAL
    INTO   :new.id
    FROM   dual;
  END;