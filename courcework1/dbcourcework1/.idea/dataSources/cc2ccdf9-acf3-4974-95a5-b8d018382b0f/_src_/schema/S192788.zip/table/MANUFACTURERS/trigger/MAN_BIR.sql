create trigger MAN_BIR
	before insert
	on MANUFACTURERS
	for each row
BEGIN
    SELECT man_seq_key.NEXTVAL
    INTO   :new.id
    FROM   dual;
  END;