create trigger GPU_BIR
	before insert
	on GPUS
	for each row
BEGIN
    SELECT gpu_seq_key.NEXTVAL
    INTO   :new.id
    FROM   dual;
  END;