create trigger ORDERS_BIR
	before insert
	on ORDERS
	for each row
BEGIN
    SELECT orders_seq_key.NEXTVAL
    INTO   :new.id
    FROM   dual;
  END;