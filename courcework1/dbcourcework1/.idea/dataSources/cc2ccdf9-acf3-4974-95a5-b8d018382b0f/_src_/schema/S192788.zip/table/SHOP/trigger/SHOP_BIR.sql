create trigger SHOP_BIR
	before insert
	on SHOP
	for each row
BEGIN
    SELECT shop_seq_key.NEXTVAL
    INTO   :new.id
    FROM   dual;
  END;